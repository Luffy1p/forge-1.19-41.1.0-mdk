package net.luffy.tutorialmod.event;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.luffy.tutorialmod.TutorialMod;
import net.luffy.tutorialmod.item.Moditems;
import net.luffy.tutorialmod.villager.ModVillagers;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = TutorialMod.MOD_ID)
public class ModEvents {
    @SubscribeEvent
    public static void addCustomTrades(VillagerTradesEvent event) {
        if (event.getType() == VillagerProfession.TOOLSMITH) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            ItemStack netherStarStack = new ItemStack(Items.NETHER_STAR, 1);
            int villagerLevel = 1;

            trades.get(villagerLevel).add((VillagerTrades.ItemListing) new MerchantOffer(
                    new ItemStack(Items.EMERALD, 15),
                    netherStarStack, 10, 8, 0.02F));
        }

        if (event.getType() == ModVillagers.JUMPY_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();

            // Adding another trade for CobbleStone to Iron Ingots
            ItemStack cobblestoneStack2 = new ItemStack(Items.COBBLESTONE, 32);
            ItemStack ironingotStack2 = new ItemStack(Items.IRON_INGOT, 64);
            int villagerLevel1 = 1;

            trades.get(villagerLevel1).add((VillagerTrades.ItemListing) new MerchantOffer(
                    cobblestoneStack2,
                    ironingotStack2, 10, 8, 0.02F));

            // Adding another trade for Iron Ingots to Copper Ingots
            ItemStack ironingotStack3 = new ItemStack(Items.IRON_INGOT, 32);
            ItemStack copperingotStack2 = new ItemStack(Items.COPPER_INGOT, 64);
            int villagerLevel2 = 2;

            trades.get(villagerLevel2).add((VillagerTrades.ItemListing) new MerchantOffer(
                    ironingotStack3,
                    copperingotStack2, 10, 8, 0.02F));

            // Adding another trade for Copper Ingots to Gold Ingots
            ItemStack copperingotsStack3 = new ItemStack(Items.COPPER_INGOT, 32);
            ItemStack goldingotsStack2 = new ItemStack(Items.GOLD_INGOT, 64);
            int villagerLevel3 = 3;

            trades.get(villagerLevel3).add((VillagerTrades.ItemListing) new MerchantOffer(
                    copperingotsStack3 ,
                    goldingotsStack2, 10, 8, 0.02F));

            // Adding another trade for Gold Ingots to Diamonds
            ItemStack goldingotStack3 = new ItemStack(Items.GOLD_INGOT, 32);
            ItemStack diamondStack2 = new ItemStack(Items.DIAMOND, 10);
            int villagerLevel4 = 4;

            trades.get(villagerLevel4).add((VillagerTrades.ItemListing) new MerchantOffer(
                    goldingotStack3,
                    diamondStack2, 10, 8, 0.02F));

            // Adding another trade for Diamonds to Emeralds
            ItemStack diamondBlockStack2 = new ItemStack(Items.DIAMOND, 16);
            ItemStack emeraldStack2 = new ItemStack(Items.EMERALD, 10);
            int villagerLevel5 = 5;

            trades.get(villagerLevel5).add((VillagerTrades.ItemListing) new MerchantOffer(
                    diamondBlockStack2,
                    emeraldStack2 , 10, 8, 0.02F));

            // Adding another trade for emeralds to Nether Stars
            ItemStack emeraldStack3 = new ItemStack(Items.EMERALD, 32);
            ItemStack netherStarStack2 = new ItemStack(Items.NETHER_STAR, 2);
            int villagerLevel6 = 6;

            trades.get(villagerLevel6).add((VillagerTrades.ItemListing) new MerchantOffer(
                    emeraldStack2,
                    netherStarStack2, 10, 8, 0.02F));
        }
    }
}
